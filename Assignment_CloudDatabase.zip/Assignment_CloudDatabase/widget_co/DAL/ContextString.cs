using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    //return connnection string
    public static class ContextString
    {
        private static string ConnString = "Server=tcp:assignmentcloudserver.database.windows.net,1433;Initial Catalog=assignmentcloudDatabase;Persist Security Info=False;User ID=cheeyauinholland;Password=#$5634twda%6dssdf;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        //private static string ConnString { get => "Server=localhost\\sqlexpress;Database=clouddatabase;Trusted_Connection=True"; }
        public static string getString()
        {
            return ConnString;
        }
    }
}

